<h4 class="gf-post-title heading-color"><?php the_title() ?></h4>
