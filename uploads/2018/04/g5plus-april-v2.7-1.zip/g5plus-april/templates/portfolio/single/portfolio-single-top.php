<?php
/**
 * Created by PhpStorm.
 * User: thanglk
 * Date: 26/09/2017
 * Time: 3:26 CH
 */
g5Theme()->helper()->getTemplate('portfolio/single/portfolio-gallery');