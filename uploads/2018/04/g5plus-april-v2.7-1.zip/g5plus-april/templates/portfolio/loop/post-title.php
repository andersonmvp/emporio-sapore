<?php
/**
 * The template for displaying post-title.php
 *
 * @package WordPress
 * @subpackage april
 * @since april 1.0
 */
?>
<h3 class="gsf-portfolio-title fs-20 mg-bottom-10"><a title="<?php the_title() ?>" href="<?php g5Theme()->portfolio()->the_permalink() ?>"><?php the_title() ?></a></h3>
