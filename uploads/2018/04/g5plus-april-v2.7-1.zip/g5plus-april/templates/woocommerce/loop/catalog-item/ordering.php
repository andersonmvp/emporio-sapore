<?php
/**
 * Created by PhpStorm.
 * User: thanglk
 * Date: 07/08/2017
 * Time: 8:10 SA
 */

woocommerce_catalog_ordering();