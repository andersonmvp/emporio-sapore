<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 4/6/2016
 * Time: 3:59 PM
 */
if (!defined('ABSPATH')) {
    die('-1');
}
class WPBakeryShortCode_GSF_Testimonials extends G5P_ShortCode_Base {

}