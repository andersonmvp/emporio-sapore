<?php
/**
 * The template for displaying products-index.php
 *
 * @package WordPress
 * @subpackage april
 * @since april 1.0
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_GSF_Products_Index extends G5P_ShortCode_Base {
}
